import WaterJugs as P

# some ideas for doing simple testing to ensure correctness
# of the State and Problem classes for the Water Jugs problem

# create a problem instance with a target value of 1
problem = P.Problem(1) 
# see if the initial state looks right
s = problem.create_initial_state()
print(s)

# check if applying an action leads to the correct next state
# exacty what form the 'action' takes depends on your action
# representation.  The approach here is a bad (but possible) one.
action = "Fill jug 15"
new_state = problem.result(s, action)
print(new_state)

# make sure applying an action didn't change the original state!
print(s)
