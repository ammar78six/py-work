# CMPT 317: Problem Class Template

# Copyright (c) 2016-2019 Michael C Horsch and Jeff Long,
# Department of Computer Science, University of Saskatchewan

# This file is provided solely for the use of CMPT 317 students.  Students are permitted
# to use this file for their own studies, and to make copies for their own personal use.

# This file should not be posted on any public server, or made available to any party not
# enrolled in CMPT 317.

# This implementation is provided on an as-is basis, suitable for educational purposes only.
#

import random as rand
import math as math

class State(object):

    def __init__(self, preceding_action):
        """
        Initialize the State object.
        """
        # each state MUST store the action that created it
        # if you want to be able to actually see your solutions
        self.action = preceding_action
        pass


    def __str__(self):
        """ A string representation of the State """
        return ""

    def __eq__(self, other):
        """ Allows states to be compared"""
        return False

    


class Problem(object):
    """The Problem class defines aspects of the problem.
       One of the important definitions is the transition model for states.
       To interact with search classes, the transition model is defined by:
            is_goal(s): returns true if the state is a goal state.
            actions(s): returns a list of all legal actions in state s
            result(s,a): returns a new state, the result of doing action a in state s

    """

    def __init__(self, goal):
        """ The problem is defined by a target value.  We want to measure that many
        liters of water.

            :param goal: the number of liters of water we want to measure

        """
        self.goal = goal
        # INSERT WHATEVER ELSE YOU NEED HERE


    def create_initial_state(self):
        """ returns an initial state 
        """  
        return None

    def is_goal(self, a_state:State):
        """Determine whether a_state is a goal state"""

        return False

    def actions(self, a_state:State):
        """ Returns all the actions that are legal in the given state.
            
        """
       
        return []

    def result(self, a_state:State, an_action):
        """Implements the transition function.
        Given a state and an action, return the resulting state.
          
        """        
    
        return None



            
# end of file

