# CMPT 317: Script for colored tile problem

# Copyright (c) 2022 Jeff Long
# Department of Computer Science, University of Saskatchewan

# This script solves a Water Jug problem using
# a search strategy given on command line and
# displays the sequence of actions needed to 
# solve the problem


import UninformedSearch as BlindSearch
import WaterJugs as P

import sys as sys
import time as time

# process the command line arguments
#print(sys.argv)

if len(sys.argv) < 5:
    print('usage: python', sys.argv[0], 'target_value <DFS,BFS,IDS> <tree,graph> time_limit')
    sys.exit()

target = int(sys.argv[1])
algorithm = sys.argv[2]
search_type = sys.argv[3]
timelimit = int(sys.argv[4])


# search using IDS and graph search

problem = P.Problem(target)
s = problem.create_initial_state()
searcher = BlindSearch.Search(problem, timelimit=timelimit)

# call a different search algorithm depending on command line

if algorithm.upper() == "DFS":
    answer = search.DFS(s, search_type)
elif algorithm.upper() == "BFS":
    answer = search.BFS(s, search_type)
elif algorithm.upper() == "IDS":
    answer = searcher.IDS(s, search_type)

print("Searching using",algorithm, "with",search_type,"search")
if answer.success:
    print(answer.result.depth, "actions needed to solve problem for target of",target,"liter")
    
    # NOTE: Your state class needs to store the action that created it using a class variable called "action" in order to use this!
    answer.result.display_steps()
else:
    print("Could not solve problem")
print()
print("Search took",answer.time, "seconds")
print("Memory used:",answer.space,"nodes")
print("----------------")



